package com.mindmatrix.nammarastereporter

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : ComponentActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var database: ReportDatabase
    private lateinit var previewView: PreviewView
    private lateinit var statusInput: EditText
    private var imageCapture: ImageCapture? = null
    private var selectedIssueType = IssueType.POTHOLE
    private var selectedSeverity = Severity.HIGH
    private var currentUser = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("namma_raste_user", MODE_PRIVATE)
        database = ReportDatabase(this)
        currentUser = prefs.getString(KEY_USER, "").orEmpty()

        if (currentUser.isBlank()) {
            showLogin()
        } else {
            showReporter()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS) {
            showReporter()
        }
    }

    private fun showLogin() {
        val root = verticalRoot()
        root.gravity = Gravity.CENTER_VERTICAL
        root.addView(hero("Namma-Raste Reporter", "One-click road and streetlight issue reporting"))

        val nameInput = input("Name or mobile number")
        root.addView(card {
            addView(sectionTitle("Citizen Login"))
            addView(body("Login prevents spam and links every ticket to a responsible reporter."))
            addView(nameInput)
            addView(primaryButton("Continue") {
                val value = nameInput.text.toString().trim()
                if (value.length < 3) {
                    toast("Enter at least 3 characters")
                } else {
                    currentUser = value
                    prefs.edit().putString(KEY_USER, value).apply()
                    hideKeyboard(nameInput)
                    showReporter()
                }
            })
        })
        setContentView(scroll(root))
    }

    private fun showReporter() {
        val root = verticalRoot()
        root.addView(header("Namma-Raste Reporter", "Logged in as $currentUser"))

        if (!hasCameraPermission()) {
            root.addView(card {
                addView(sectionTitle("Camera permission needed"))
                addView(body("Allow camera access to capture potholes or broken streetlights. Location is used for exact repair coordinates."))
                addView(primaryButton("Allow permissions") { requestNeededPermissions() })
            })
            setContentView(scroll(root))
            return
        }

        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        val cameraFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(previewView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(330)))
        }
        root.addView(cameraFrame)

        root.addView(card {
            addView(sectionTitle("Capture Mode"))
            addView(body("Select the fault type, set severity, then capture. Time and GPS are attached automatically."))
            addView(segmentedIssueButtons())
            addView(segmentedSeverityButtons())
            addView(primaryButton("Capture and submit report") { captureAndSubmit() })
        })

        statusInput = input("Enter Ticket ID")
        root.addView(card {
            addView(sectionTitle("Status Tracker"))
            addView(statusInput)
            addView(primaryButton("Check status") { showTicketStatus() })
            addView(secondaryButton("Recent reports") { showRecentReports() })
        })

        root.addView(secondaryButton("Logout") {
            prefs.edit().remove(KEY_USER).apply()
            currentUser = ""
            showLogin()
        })

        setContentView(scroll(root))
        startCamera()
    }

    private fun captureAndSubmit() {
        val capture = imageCapture
        if (capture == null) {
            toast("Camera is starting. Try again in a moment.")
            return
        }

        val ticketId = generateTicketId()
        val photoFile = File(filesDir, "$ticketId.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()
        val buttonStateMessage = "Submitting $ticketId..."
        toast(buttonStateMessage)

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    val location = latestLocation()
                    val report = InfrastructureReport(
                        ticketId = ticketId,
                        issueType = selectedIssueType.label,
                        severity = selectedSeverity.label,
                        status = "Submitted",
                        createdAt = timestamp(),
                        latitude = location?.latitude,
                        longitude = location?.longitude,
                        photoPath = photoFile.absolutePath,
                        reporter = currentUser,
                    )
                    database.insertReport(report)
                    showSubmitted(report)
                }

                override fun onError(exception: ImageCaptureException) {
                    toast("Photo failed: ${exception.message ?: "camera error"}")
                }
            },
        )
    }

    private fun showSubmitted(report: InfrastructureReport) {
        val root = verticalRoot()
        root.addView(header("Report Submitted", report.ticketId))
        root.addView(ticketCard(report))
        root.addView(primaryButton("Create another report") { showReporter() })
        root.addView(secondaryButton("Track this ticket") {
            showReporter()
            statusInput.setText(report.ticketId)
            showTicketStatus()
        })
        setContentView(scroll(root))
    }

    private fun showTicketStatus() {
        val ticketId = statusInput.text.toString().trim().uppercase(Locale.US)
        hideKeyboard(statusInput)
        val report = database.findByTicket(ticketId)
        if (report == null) {
            toast("Ticket not found")
            return
        }

        val root = verticalRoot()
        root.addView(header("Ticket Status", report.ticketId))
        root.addView(ticketCard(report))
        root.addView(primaryButton("Back to camera") { showReporter() })
        setContentView(scroll(root))
    }

    private fun showRecentReports() {
        val root = verticalRoot()
        val reports = database.recentReports()
        root.addView(header("Recent Reports", "${reports.size} saved on this phone"))
        if (reports.isEmpty()) {
            root.addView(card {
                addView(sectionTitle("No reports yet"))
                addView(body("Capture the first pothole or streetlight issue to create a ticket."))
            })
        } else {
            reports.forEach { report -> root.addView(ticketCard(report)) }
        }
        root.addView(primaryButton("Back to camera") { showReporter() })
        setContentView(scroll(root))
    }

    private fun ticketCard(report: InfrastructureReport): View {
        val locationText = if (report.latitude != null && report.longitude != null) {
            "%.5f, %.5f".format(Locale.US, report.latitude, report.longitude)
        } else {
            "Location unavailable"
        }
        return card {
            addView(sectionTitle(report.ticketId))
            addView(body("${report.issueType} - ${report.severity} severity"))
            addView(body("Status: ${report.status}"))
            addView(body("Time: ${report.createdAt}"))
            addView(body("GPS: $locationText"))
            addView(body("Photo saved locally: ${report.photoPath}"))
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val cameraProvider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                imageCapture,
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun segmentedIssueButtons(): View {
        return horizontalGroup(
            optionButton(IssueType.POTHOLE.label, selectedIssueType == IssueType.POTHOLE) {
                selectedIssueType = IssueType.POTHOLE
                showReporter()
            },
            optionButton(IssueType.STREETLIGHT.label, selectedIssueType == IssueType.STREETLIGHT) {
                selectedIssueType = IssueType.STREETLIGHT
                showReporter()
            },
        )
    }

    private fun segmentedSeverityButtons(): View {
        return horizontalGroup(
            optionButton(Severity.LOW.label, selectedSeverity == Severity.LOW) {
                selectedSeverity = Severity.LOW
                showReporter()
            },
            optionButton(Severity.MEDIUM.label, selectedSeverity == Severity.MEDIUM) {
                selectedSeverity = Severity.MEDIUM
                showReporter()
            },
            optionButton(Severity.HIGH.label, selectedSeverity == Severity.HIGH) {
                selectedSeverity = Severity.HIGH
                showReporter()
            },
        )
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_PERMISSIONS)
    }

    private fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }

    private fun latestLocation(): Location? {
        if (
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }
        val manager = getSystemService(LocationManager::class.java)
        return manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
    }

    private fun generateTicketId(): String {
        val datePart = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(Date())
        val suffix = UUID.randomUUID().toString().take(5).uppercase(Locale.US)
        return "NRR-$datePart-$suffix"
    }

    private fun timestamp(): String = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date())

    private fun verticalRoot(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(26))
            setBackgroundColor(Color.rgb(247, 250, 248))
        }
    }

    private fun scroll(content: View): ScrollView = ScrollView(this).apply {
        addView(content)
        isFillViewport = true
    }

    private fun hero(title: String, subtitle: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(18))
            addView(TextView(context).apply {
                text = title
                textSize = 30f
                setTextColor(Color.rgb(19, 35, 28))
                gravity = Gravity.CENTER
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            addView(TextView(context).apply {
                text = subtitle
                textSize = 15f
                setTextColor(Color.rgb(74, 86, 80))
                gravity = Gravity.CENTER
            })
        }
    }

    private fun header(title: String, subtitle: String): View {
        return card {
            addView(sectionTitle(title))
            addView(body(subtitle))
        }
    }

    private fun card(build: LinearLayout.() -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.WHITE)
            elevation = dp(2).toFloat()
            build()
        }.also {
            it.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).withMargins(bottom = 12)
        }
    }

    private fun sectionTitle(value: String): TextView {
        return TextView(this).apply {
            text = value
            textSize = 20f
            setTextColor(Color.rgb(19, 35, 28))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, dp(6))
        }
    }

    private fun body(value: String): TextView {
        return TextView(this).apply {
            text = value
            textSize = 15f
            setTextColor(Color.rgb(65, 76, 71))
            setLineSpacing(2f, 1.05f)
            setPadding(0, 0, 0, dp(8))
        }
    }

    private fun input(hintValue: String): EditText {
        return EditText(this).apply {
            hint = hintValue
            setSingleLine(true)
            textSize = 16f
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }.also {
            it.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).withMargins(bottom = 10)
        }
    }

    private fun primaryButton(textValue: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = textValue
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(37, 109, 82))
            setOnClickListener { action() }
        }.withButtonMargins()
    }

    private fun secondaryButton(textValue: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = textValue
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(68, 82, 77))
            setOnClickListener { action() }
        }.withButtonMargins()
    }

    private fun optionButton(textValue: String, selected: Boolean, action: () -> Unit): Button {
        return Button(this).apply {
            text = textValue
            textSize = 12f
            minHeight = dp(42)
            setTextColor(if (selected) Color.WHITE else Color.rgb(19, 35, 28))
            setBackgroundColor(if (selected) Color.rgb(37, 109, 82) else Color.rgb(230, 237, 233))
            setOnClickListener { action() }
        }
    }

    private fun horizontalGroup(vararg children: View): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            children.forEachIndexed { index, child ->
                val params = LinearLayout.LayoutParams(0, dp(48), 1f)
                    .withMargins(start = if (index == 0) 0 else 4, end = if (index == children.lastIndex) 0 else 4, bottom = 8)
                addView(child, params)
            }
        }
    }

    private fun Button.withButtonMargins(): Button {
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(48),
        ).withMargins(top = 4, bottom = 4)
        return this
    }

    private fun hideKeyboard(view: View) {
        val manager = getSystemService(InputMethodManager::class.java)
        manager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun LinearLayout.LayoutParams.withMargins(
        start: Int = 0,
        top: Int = 0,
        end: Int = 0,
        bottom: Int = 0,
    ): LinearLayout.LayoutParams {
        setMargins(dp(start), dp(top), dp(end), dp(bottom))
        return this
    }

    companion object {
        private const val KEY_USER = "reporter"
        private const val REQUEST_PERMISSIONS = 41
    }
}

enum class IssueType(val label: String) {
    POTHOLE("Pothole"),
    STREETLIGHT("Streetlight"),
}

enum class Severity(val label: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
}

data class InfrastructureReport(
    val ticketId: String,
    val issueType: String,
    val severity: String,
    val status: String,
    val createdAt: String,
    val latitude: Double?,
    val longitude: Double?,
    val photoPath: String,
    val reporter: String,
)

class ReportDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE reports (
                ticket_id TEXT PRIMARY KEY,
                issue_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                latitude REAL,
                longitude REAL,
                photo_path TEXT NOT NULL,
                reporter TEXT NOT NULL
            )
            """.trimIndent(),
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS reports")
        onCreate(db)
    }

    fun insertReport(report: InfrastructureReport) {
        writableDatabase.insertWithOnConflict("reports", null, report.values(), SQLiteDatabase.CONFLICT_ABORT)
    }

    fun findByTicket(ticketId: String): InfrastructureReport? {
        readableDatabase.query(
            "reports",
            null,
            "ticket_id = ?",
            arrayOf(ticketId),
            null,
            null,
            null,
        ).use { cursor ->
            return if (cursor.moveToFirst()) cursor.toReport() else null
        }
    }

    fun recentReports(): List<InfrastructureReport> {
        val reports = mutableListOf<InfrastructureReport>()
        readableDatabase.query(
            "reports",
            null,
            null,
            null,
            null,
            null,
            "created_at DESC",
            "10",
        ).use { cursor ->
            while (cursor.moveToNext()) {
                reports.add(cursor.toReport())
            }
        }
        return reports
    }

    private fun InfrastructureReport.values(): ContentValues {
        return ContentValues().apply {
            put("ticket_id", ticketId)
            put("issue_type", issueType)
            put("severity", severity)
            put("status", status)
            put("created_at", createdAt)
            put("latitude", latitude)
            put("longitude", longitude)
            put("photo_path", photoPath)
            put("reporter", reporter)
        }
    }

    private fun android.database.Cursor.toReport(): InfrastructureReport {
        return InfrastructureReport(
            ticketId = getString(getColumnIndexOrThrow("ticket_id")),
            issueType = getString(getColumnIndexOrThrow("issue_type")),
            severity = getString(getColumnIndexOrThrow("severity")),
            status = getString(getColumnIndexOrThrow("status")),
            createdAt = getString(getColumnIndexOrThrow("created_at")),
            latitude = getNullableDouble("latitude"),
            longitude = getNullableDouble("longitude"),
            photoPath = getString(getColumnIndexOrThrow("photo_path")),
            reporter = getString(getColumnIndexOrThrow("reporter")),
        )
    }

    private fun android.database.Cursor.getNullableDouble(column: String): Double? {
        val index = getColumnIndexOrThrow(column)
        return if (isNull(index)) null else getDouble(index)
    }

    companion object {
        private const val DB_NAME = "namma_raste_reports.db"
        private const val DB_VERSION = 1
    }
}
